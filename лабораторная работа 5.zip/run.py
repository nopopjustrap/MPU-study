import sqlite3

# Подключаемся к базе данных SQLite
conn = sqlite3.connect('database.db')
cursor = conn.cursor()


# Функция для вывода содержимого таблицы
def print_table(table_name):
    print(f"\nСодержимое таблицы {table_name}:")
    cursor.execute(f"SELECT * FROM {table_name}")
    rows = cursor.fetchall()

    # Получаем имена колонок таблицы
    column_names = [description[0] for description in cursor.description]
    print(column_names)  # Печатаем имена колонок

    # Печатаем строки таблицы
    for row in rows:
        print(row)


# Список всех таблиц в базе данных
table_names = [
    'должность', 'персонал', 'финансы', 'ЛК_клиента', 'Заказ',
    'Корзина', 'Товар', 'рецепт', 'поставки', 'Ингредиент', 'поставщик'
]

# Вывод содержимого каждой таблицы
for table_name in table_names:
    print_table(table_name)

# Закрываем соединение
conn.close()
