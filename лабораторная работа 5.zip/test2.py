import sqlite3

# Connect to the SQLite database (or create it if it doesn't exist)
conn = sqlite3.connect('database.db')
cursor = conn.cursor()


# Create tables
cursor.execute("DROP TABLE IF EXISTS должность")
cursor.execute('''
CREATE TABLE IF NOT EXISTS должность (
    ID_должности INTEGER PRIMARY KEY,
    должность TEXT
)
''')
cursor.execute("DROP TABLE IF EXISTS персонал")
cursor.execute('''
CREATE TABLE IF NOT EXISTS персонал (
    ID_сотрудника INTEGER PRIMARY KEY,
    фамилия TEXT,
    имя TEXT,
    отчество TEXT,
    зп REAL,
    ID_должности INTEGER,
    FOREIGN KEY (ID_должности) REFERENCES должность(ID_должности)
)
''')
cursor.execute("DROP TABLE IF EXISTS финансы")
cursor.execute('''
CREATE TABLE IF NOT EXISTS финансы (
    ID_записи INTEGER PRIMARY KEY,
    ID_заказа INTEGER,
    дата TEXT,
    тип_записи TEXT,
    сумма REAL
)
''')
cursor.execute("DROP TABLE IF EXISTS ЛК_клиента")
cursor.execute('''
CREATE TABLE IF NOT EXISTS ЛК_клиента (
    ID_клиента INTEGER PRIMARY KEY,
    фамилия TEXT,
    имя TEXT,
    отчество TEXT,
    номер_телефона TEXT,
    почта TEXT,
    бонусные_баллы INTEGER
)
''')
cursor.execute("DROP TABLE IF EXISTS Заказ")
cursor.execute('''
CREATE TABLE IF NOT EXISTS Заказ (
    ID_заказа INTEGER PRIMARY KEY,
    ID_клиента INTEGER,
    дата_заказа TEXT,
    статус_заказа TEXT,
    общая_стоимость REAL,
    FOREIGN KEY (ID_клиента) REFERENCES ЛК_клиента(ID_клиента)
)
''')
cursor.execute("DROP TABLE IF EXISTS Корзина")
cursor.execute('''
CREATE TABLE IF NOT EXISTS Корзина (
    ID_корзины INTEGER PRIMARY KEY,
    ID_заказа INTEGER,
    ID_товара INTEGER,
    FOREIGN KEY (ID_заказа) REFERENCES Заказ(ID_заказа),
    FOREIGN KEY (ID_товара) REFERENCES Товар(ID_товара)
)
''')
cursor.execute("DROP TABLE IF EXISTS Товар")
cursor.execute('''
CREATE TABLE IF NOT EXISTS Товар (
    ID_товара INTEGER PRIMARY KEY,
    ID_рецепта INTEGER,
    название TEXT,
    дата_изготовления TEXT,
    кол_во_на_складе INTEGER,
    себестоимость REAL,
    срок_годности TEXT
)
''')
cursor.execute("DROP TABLE IF EXISTS рецепт")
cursor.execute('''
CREATE TABLE IF NOT EXISTS рецепт (
    ID_рецепта INTEGER PRIMARY KEY,
    название TEXT,
    ID_ингредиента INTEGER,
    кол_во_ингредиента REAL
)
''')
cursor.execute("DROP TABLE IF EXISTS поставки")
cursor.execute('''
CREATE TABLE IF NOT EXISTS поставки (
    ID_ингредиента INTEGER,
    кол_во_ингредиента REAL,
    дата_поставки TEXT,
    ID_поставщика INTEGER,
    PRIMARY KEY (ID_ингредиента, ID_поставщика)
)
''')
cursor.execute("DROP TABLE IF EXISTS Ингредиент")
cursor.execute('''
CREATE TABLE IF NOT EXISTS Ингредиент (
    ID_ингредиента INTEGER PRIMARY KEY,
    ID_поставщика INTEGER,
    название TEXT,
    дата_поставки TEXT,
    количество INTEGER,
    стоимость REAL,
    срок_годности TEXT,
    FOREIGN KEY (ID_поставщика) REFERENCES поставщик(ID_поставщика)
)
''')

cursor.execute("DROP TABLE IF EXISTS поставщик")
cursor.execute('''
CREATE TABLE IF NOT EXISTS поставщик (
    ID_поставщика INTEGER PRIMARY KEY,
    Фамилия TEXT,
    Имя TEXT,
    Отчество TEXT,
    контактная_информация TEXT,
    условия_поставок TEXT
)
''')

# Insert data for each table
cursor.execute("DELETE FROM должность")

# Insert data into "должность"
cursor.executemany('''
INSERT INTO должность (ID_должности, должность) VALUES (?, ?)
''', [
    (1, 'Менеджер'),
    (2, 'Кассир'),
    (3, 'Повар'),
    (4, 'Официант'),
    (5, 'Уборщик')
])
cursor.execute("DELETE FROM персонал")

# Insert data into "персонал"
cursor.executemany('''
INSERT INTO персонал (ID_сотрудника, фамилия, имя, отчество, зп, ID_должности) VALUES (?, ?, ?, ?, ?, ?)
''', [
    (1, 'Иванов', 'Иван', 'Иванович', 60000, 1),
    (2, 'Петров', 'Петр', 'Петрович', 45000, 2),
    (3, 'Сидоров', 'Сидор', 'Сидорович', 40000, 3),
    (4, 'Кузнецов', 'Алексей', 'Алексеевич', 38000, 4),
    (5, 'Смирнова', 'Мария', 'Сергеевна', 30000, 5)
])
cursor.execute("DELETE FROM финансы")

# Insert data into "финансы"
cursor.executemany('''
INSERT INTO финансы (ID_записи, ID_заказа, дата, тип_записи, сумма) VALUES (?, ?, ?, ?, ?)
''', [
    (1, 1, '2023-01-10', 'Платеж', 1500),
    (2, 2, '2023-01-15', 'Платеж', 2000),
    (3, 3, '2023-01-20', 'Платеж', 2500),
    (4, 4, '2023-01-25', 'Платеж', 3000),
    (5, 5, '2023-01-30', 'Платеж', 3500)
])
cursor.execute("DELETE FROM ЛК_клиента")

# Insert data into "ЛК_клиента"
cursor.executemany('''
INSERT INTO ЛК_клиента (ID_клиента, фамилия, имя, отчество, номер_телефона, почта, бонусные_баллы) VALUES (?, ?, ?, ?, ?, ?, ?)
''', [
    (1, 'Сергеев', 'Сергей', 'Сергеевич', '1234567890', 'sergeev@example.com', 100),
    (2, 'Федорова', 'Анна', 'Федоровна', '0987654321', 'fedorova@example.com', 150),
    (3, 'Михайлов', 'Дмитрий', 'Михайлович', '1111111111', 'mihailov@example.com', 200),
    (4, 'Козлова', 'Ольга', 'Викторовна', '2222222222', 'kozlova@example.com', 250),
    (5, 'Васильев', 'Александр', 'Александрович', '3333333333', 'vasiliev@example.com', 300)
])
# Данные для "Заказ"
cursor.executemany('''
INSERT OR IGNORE INTO Заказ (ID_заказа, ID_клиента, дата_заказа, статус_заказа, общая_стоимость) VALUES (?, ?, ?, ?, ?)
''', [
    (1, 1, '2023-02-01', 'Завершен', 500),
    (2, 2, '2023-02-05', 'Ожидание', 300),
    (3, 3, '2023-02-10', 'Отменен', 200),
    (4, 4, '2023-02-15', 'Завершен', 450),
    (5, 5, '2023-02-20', 'Завершен', 350)
])

# Данные для "Корзина"
cursor.executemany('''
INSERT OR IGNORE INTO Корзина (ID_корзины, ID_заказа, ID_товара) VALUES (?, ?, ?)
''', [
    (1, 1, 1),
    (2, 1, 2),
    (3, 2, 3),
    (4, 3, 4),
    (5, 4, 5)
])

# Данные для "Товар"
cursor.executemany('''
INSERT OR IGNORE INTO Товар (ID_товара, ID_рецепта, название, дата_изготовления, кол_во_на_складе, себестоимость, срок_годности) VALUES (?, ?, ?, ?, ?, ?, ?)
''', [
    (1, 1, 'Круасан с шоколадом', '2023-01-01', 100, 150, '2024-01-01'),
    (2, 2, 'Багет', '2023-02-01', 200, 250, '2024-02-01'),
    (3, 3, 'Хлеб', '2023-03-01', 300, 350, '2024-03-01'),
    (4, 4, 'Булочка с корицей', '2023-04-01', 400, 450, '2024-04-01'),
    (5, 5, 'Булочка с маком', '2023-05-01', 500, 550, '2024-05-01')
])

# Данные для "рецепт"
cursor.executemany('''
INSERT OR IGNORE INTO рецепт (ID_рецепта, название, ID_ингредиента, кол_во_ингредиента) VALUES (?, ?, ?, ?)
''', [
    (1, 'Рецепт круасана', 1, 2.5),
    (2, 'Рецепт хлеба', 2, 3.5),
    (3, 'Рецепт багета', 3, 4.5),
    (4, 'Рецепт булочки с корицей', 4, 5.5),
    (5, 'Рецепт булочки с маком', 5, 6.5)
])

# Данные для "поставки"
cursor.executemany('''
INSERT OR IGNORE INTO поставки (ID_ингредиента, кол_во_ингредиента, дата_поставки, ID_поставщика) VALUES (?, ?, ?, ?)
''', [
    (1, 100, '2023-01-01', 1),
    (2, 200, '2023-01-15', 2),
    (3, 300, '2023-02-01', 3),
    (4, 400, '2023-02-15', 4),
    (5, 500, '2023-03-01', 5)
])

# Данные для "Ингредиент"
cursor.executemany('''
INSERT OR IGNORE INTO Ингредиент (ID_ингредиента, ID_поставщика, название, дата_поставки, количество, стоимость, срок_годности) VALUES (?, ?, ?, ?, ?, ?, ?)
''', [
    (1, 1, 'Мука', '2023-01-01', 100, 10.0, '2024-01-01'),
    (2, 2, 'Молоко', '2023-01-15', 200, 15.0, '2024-01-15'),
    (3, 3, 'Шоколад', '2023-02-01', 300, 20.0, '2024-02-01'),
    (4, 4, 'Сыр', '2023-02-15', 400, 25.0, '2024-02-15'),
    (5, 5, 'Сахар', '2023-03-01', 500, 30.0, '2024-03-01')
])

# Данные для "поставщик"

cursor.executemany('''
INSERT OR IGNORE INTO поставщик (ID_поставщика, Фамилия, Имя, Отчество, контактная_информация, условия_поставок) VALUES (?, ?, ?, ?, ?, ?)
''', [
    (1, 'Иванов', 'Иван', 'Иванович', '123-456', 'Ежемесячные поставки'),
    (2, 'Петров', 'Петр', 'Петрович', '789-012', 'Разовые поставки'),
    (3, 'Александров', 'Александр', 'Александрович', '345-678', 'Поставки по запросу'),
    (4, 'Гуляев', 'Матвей', 'Максимович', '901-234', 'Поставки с отсрочкой'),
    (5, 'Сидоров', 'Иван', 'Александрович', '567-890', 'Специальные условия')
])


# Commit changes
conn.commit()

# Close connection
conn.close()


print("Tables created and data inserted successfully.")
